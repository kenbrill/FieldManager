# FieldManager
A Custom Field Manager for optimizing SugarCRM
