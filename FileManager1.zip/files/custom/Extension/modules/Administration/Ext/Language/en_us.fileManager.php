<?php
//FileManager1
$mod_strings['LBL_FIELDMANAGER_LINK_NAME'] = 'Field Manager';
$mod_strings['LBL_FIELDMANAGER_LINK_DESCRIPTION'] = 'Reports on Field Issues';
